import java.util.Scanner;

public class FizzBuzz {
    public static void main(String [] arg)
    {
        Scanner scanner= new Scanner(System.in);
        System.out.println("Enter number: ");
        int number = scanner.nextInt();
     /*FIRST METHOD

        if (number%5 ==0 && number%3 == 0){
            System.out.println("fizzbuzz");
         }
        else if(number%5 == 0) {
            System.out.println("fizz");
        }
        else if (number%3 == 0) {
            System.out.println("buzz");
        }
        else {
            System.out.println(number);
        }
*/
        // SECOND METHOD

        if(number%5==0){
            if(number%3==0)
                System.out.println("fizzbuzz");
            else
                System.out.println("fizz");
        }
        else if (number%3 == 0) {
            System.out.println("buzz");
        }
        else {
            System.out.println(number);
        }
    }
}
